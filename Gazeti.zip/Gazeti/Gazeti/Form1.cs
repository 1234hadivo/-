﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gazeti
{
    
    public partial class Form1 : Form
    {
        Model1 db = new Model1();
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            agentBindingSource.DataSource = db.Agent.ToList();
            agentTypeBindingSource.DataSource = db.AgentType.ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                agentBindingSource.DataSource = db.Agent.OrderByDescending(ag => ag.Priority).ToList();
            }
            else
            {
                agentBindingSource.DataSource = db.Agent.OrderBy(a => a.Priority).ToList();
            }
        }

        private void agentDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            agentBindingSource.DataSource = db.Agent.OrderBy(a => a.AgentTypeID).ToList();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AddEditAgentForm frm = new AddEditAgentForm();
            frm.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void agentBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            Agent agent = (Agent)agentBindingSource.Current;
            try
            {
                if (agent == null) return;
                if (agent.Logo != "")
                {
                    string str = agent.Logo.Substring(1);
                    LogoPict.Image = Image.FromFile(str);
                }
                else
                {
                    LogoPict.Image = Image.FromFile("agents\\picture.png");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            agentBindingSource.DataSource = db.Agent.OrderBy(ag => ag.AgentTypeID).ToList();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedValue == null) return;
            int n = (int)comboBox1.SelectedValue;
            agentBindingSource.DataSource = db.Agent.Where(x => x.AgentTypeID == n).ToList();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gazeti
{
    public partial class AddEditAgentForm : Form
    {
        Model1 db { get; set; }
        public Agent ord { get; set; } = null;
        public AddEditAgentForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
            this.Close();
            DialogResult = DialogResult.Cancel;
        }

        private void AddEditAgentForm_Load(object sender, EventArgs e)
        {
            if (ord == null)
            {
                agentBindingSource.AddNew();
                this.Text = "Добавление новой записи" ;
            }
            else
            {
                agentBindingSource.Add(ord);
                agentTypeIDTextBox.ReadOnly = true;
            }

        }




        private void directorNameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (ord == null)
            {
                ord = (Agent) agentBindingSource.Current;
                db.Agent.Add(ord);
            }
            try
            {
                db.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка"+ex.Message);
            }
        }
    }
}
